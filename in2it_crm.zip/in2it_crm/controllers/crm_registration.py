from odoo import http
from odoo.http import request

class CRMRegistrationController(http.Controller):

    @http.route('/registration', type='http', auth='public', website=True)
    def registration_form(self, **kwargs):
        return request.render('in2it_crm.crm_registration_form_template', {})

    @http.route('/registration/submit', type='http', auth='public', website=True, csrf=True)
    def registration_submit(self, **post):

        try:
            request.env['crm.lead'].sudo().create({
                'name': post.get('subject') or 'Website Lead',  # Opportunity Title
                'contact_name': post.get('contact_name'),
                'partner_name': post.get('company_name'),

                'email_from': post.get('email'),
                'phone': post.get('phone'),
                'function': post.get('job_position'),

                # Address Fields
                'street': post.get('street'),
                'city': post.get('city'),
                'zip': post.get('zip'),

                'description': post.get('description'),

                'type': 'lead',
                'team_id': request.env['crm.team'].sudo().search([], limit=1).id,
                'user_id': request.env.user.id,
            })

            return request.redirect('/?submitted=1')

        except Exception as e:
            return request.redirect('/?error=1')