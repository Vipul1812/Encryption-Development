{
    'name': "in2it_crm",
    'summary': "CRM Registration Form",
    'description': "Website form integrated with CRM",

    'author': "My Company",
    'website': "https://www.yourcompany.com",

    'category': 'Uncategorized',
    'version': '0.1',

    'depends': ['base', 'crm', 'website'],  

    'data': [
        # 'security/ir.model.access.csv',
        'views/crm_registration_menu.xml',
        'views/crm_registration_template.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            # 'in2it_crm/static/src/scss/style.scss',
    ],
},
}